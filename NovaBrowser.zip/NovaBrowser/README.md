# Nova Browser

A free, privacy-friendly Android web browser with profiles, built-in AdBlock, gestures, bookmark filters and backups.

## Features

- Chrome-style top address bar, search pill with security (lock) indicator, tab counter and menu
- Built-in new-tab page with search box (uses the search engine selected in settings) and shortcuts
- Voice search, reader mode, find in page, desktop site, Save as PDF, home-screen shortcut
- Tabs, bookmarks, history, downloads, per-site privacy profiles, built-in AdBlock, gestures, backups
- Light/dark theme follows the system (wallpaper colours optional in Settings)

## Project info

- Package / application id: `com.novabrowser.app`
- Min SDK 24, target SDK 33
- Build: open in Android Studio, or run `./gradlew assembleRelease` (sign the APK with your own keystore)

## License and attribution

This application is derived from **FOSS Browser** (originally by Gaukler Faun), which is licensed under the
GNU Affero General Public License v3 or later. Because of that, this project remains under the same license:
see [LICENSE.md](LICENSE.md). If you distribute the app, you must make the corresponding source code available
to its users under the same license.
