package com.novabrowser.app.fragment;

import android.os.Bundle;

import com.novabrowser.app.R;
import com.novabrowser.app.preferences.BasePreferenceFragment;

public class Fragment_settings_General extends BasePreferenceFragment {
    @Override
    public void onCreatePreferences(Bundle savedInstanceState,String rootKey) {
        setPreferencesFromResource(R.xml.preference_general, rootKey);
    }
}
