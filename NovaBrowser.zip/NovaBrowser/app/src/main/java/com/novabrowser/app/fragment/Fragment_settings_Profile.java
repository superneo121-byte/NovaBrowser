package com.novabrowser.app.fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.preference.PreferenceManager;

import java.util.Objects;

import com.novabrowser.app.R;
import com.novabrowser.app.preferences.BasePreferenceFragment;

public class Fragment_settings_Profile extends BasePreferenceFragment {

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        Context context = getContext();
        assert context != null;

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        String profile = sp.getString("profileToEdit", "profileStandard");

        switch (Objects.requireNonNull(profile)) {
            case "profileStandard":
                setPreferencesFromResource(R.xml.preference_profile_standard, rootKey);
                PreferenceManager.setDefaultValues(context, R.xml.preference_profile_standard, false);
                break;
            case "profileTrusted":
                setPreferencesFromResource(R.xml.preference_profile_trusted, rootKey);
                PreferenceManager.setDefaultValues(context, R.xml.preference_profile_trusted, false);
                break;
            case "profileProtected":
                setPreferencesFromResource(R.xml.preference_profile_protected, rootKey);
                PreferenceManager.setDefaultValues(context, R.xml.preference_profile_protected, false);
                break;
        }
    }
}