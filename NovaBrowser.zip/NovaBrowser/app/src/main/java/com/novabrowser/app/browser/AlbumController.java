package com.novabrowser.app.browser;

import android.view.View;

public interface AlbumController {
    View getAlbumView();
    void activate();
    void deactivate();
}
